﻿using MatrixLib;

const int MATRIX_SIZE = 6;

var matrix = new int[6, 6];
for (var columnIndex = 0; columnIndex < MATRIX_SIZE; columnIndex++)
{
    for (var rowIndex = 0; rowIndex < MATRIX_SIZE; rowIndex++) 
        matrix[columnIndex, rowIndex] = int.Parse(Console.ReadLine()!);
}

var multiplyResult = MatrixClass.MainDiagonalMult(matrix);
Console.WriteLine($"\nResult: {multiplyResult}");