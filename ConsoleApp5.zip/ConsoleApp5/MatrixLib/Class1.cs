﻿namespace MatrixLib;

public class MatrixClass
{
    public static int MainDiagonalMult(int[,] matrix)
    {
        var size = (int)Math.Sqrt(matrix.Length);

        var result = 0;
        for (var index = 0; index < size; index++)
            result += matrix[index, index];
        
        return result;
    }
}